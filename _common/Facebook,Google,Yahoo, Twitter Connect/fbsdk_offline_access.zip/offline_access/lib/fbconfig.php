<?php
//Facebook Application Configuration.
$facebook_appid='APP ID';
$facebook_app_secret='APP Secret';

$facebook = new Facebook(array(
'appId'  => $facebook_appid,
'secret' => $facebook_app_secret,
));


?>