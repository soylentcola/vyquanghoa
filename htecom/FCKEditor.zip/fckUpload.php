<?php
	include('class_file_upload.php');
	$FileUpload = new FileUpload;
	//print_r($_FILES);
	
	$upload_dir = '/www/uploads/';
	$folder = $_REQUEST['folder'];
	
	if( !empty($folder) )
	{
		if( !is_dir($folder) )
			mkdir($upload_dir.$folder,0777 );
			
		$folder = $folder.'/';
	}
			
	if( !empty($_FILES['upload']['name']) )
	{
		$imUpload = $FileUpload->uploadFile('upload', $upload_dir.$folder );
	}
	
	$funcNum = $_GET['CKEditorFuncNum'] ;
	$message = 'Upload thanh cong.';
	$url = "/uploads/{$folder}".$imUpload;
	echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($funcNum, '$url', '$message');</script>";
?>