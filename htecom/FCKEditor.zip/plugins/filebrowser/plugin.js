var config;
config = {
	filebrowserBrowseUrl: '/browser/browse.php'
	,filebrowserUploadUrl: '/uploader/upload.php'
	,filebrowserImageUploadUrl: '/uploader/upload.php?type=Images'
	,filebrowserWindowWidth: 750
	,filebrowserWindowHeight : 580
}