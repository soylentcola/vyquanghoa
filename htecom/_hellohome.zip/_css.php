<?php	
	header('Content-type: text/css');
	$file = trim($_REQUEST['f']);
	if(empty($file))
		return false;
	
	function strTrimTotal($str_in)
	{
		$str_in = trim($str_in);
		if( empty($str_in) )
			return false;
			
		$str_in = str_replace(array("\n","\t"),' ',$str_in);
		$str_in = explode(' ',$str_in);
		$str_out = '';
		foreach( $str_in as $v )
		{
			if( ($c = trim($v)) != '' )
			{
				$str_out.= ' '.$c;
			}
		}
		return trim($str_out);
	}
	$dir = '_style/';
	if(basename($file) != $file ){
		$dir = '';
		if(substr($file,0,2) == 'js')
			$file = '_'.$file;
	}
		
	echo $style = strTrimTotal(file_get_contents($dir.$file));
?>