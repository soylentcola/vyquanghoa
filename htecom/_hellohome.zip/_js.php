<?php	
	header('Content-type: application/javascript, charset=utf-8');
	$file = trim($_REQUEST['f']);
	if(empty($file))
		return false;
	
	function strTrimTotal($str_in)
	{
		$str_in = trim($str_in);
		if( empty($str_in) )
			return false;
			
		$str_in = str_replace(array("\n","\t"),' ',$str_in);
		$str_in = explode(' ',$str_in);
		$str_out = '';
		foreach( $str_in as $v )
		{
			if( ($c = trim($v)) != '' )
			{
				$str_out.= ' '.$c;
			}
		}
		return trim($str_out);
	}
	$dir = '_js/';
	
	$file_ = str_replace('/nomin','',$file);

	if(basename($file_) != $file_)
		$dir = '_';
		
	
	if(end(explode('/',$file)) == 'nomin'){
		echo file_get_contents($dir.$file_);
	}else{
		echo strTrimTotal(file_get_contents($dir.$file));
	}
?>