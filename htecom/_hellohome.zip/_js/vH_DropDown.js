$(function(){				
	$('html').click(function(e){
		var this_;
		var parent = $(e.target).parents('.vH_DropDown');
		$(".vH_DropDown_Menu").not($('.vH_DropDown_Menu',parent)).hide();
		$('.vH_DropDown').not(parent).removeClass('open');
		return;
		
		/*if($(e.target).hasClass('vH_DropDown_Menu')){
			this_ = $(e.target);
			
		}else if($(e.target).parents('.vH_DropDown_Menu').size() > 0){
			this_ = $(e.target).parents('.vH_DropDown_Menu');
		}
		$(".vH_DropDown_Menu").not(this_).hide();*/
	});
	
	$(".vH_DropDown_Toggle").live('click',function(e){
		e.stopPropagation();
		var _this, parent = $(this).parents('.vH_DropDown');
		var this_drop_menu = $('> .vH_DropDown_Menu',parent);
		$('.vH_DropDown_Menu').not(this_drop_menu).hide();
		if(this_drop_menu.is(':visible')){
			this_drop_menu.hide();
			parent.removeClass('open');
		}else{
			this_drop_menu.show();
			parent.addClass('open');
		}
		return false;
		
	}).live('mouseover mouseleave',function(e)
	{
		e.stopPropagation();
		var _this, parent = $(this).parents('.vH_DropDown');
		var this_drop_menu = $('> .vH_DropDown_Menu',parent);
		
		if(e.type == 'mouseover')
		{
			if($('.vH_DropDown_Menu:visible').not(this_drop_menu).size() > 0){
				this_drop_menu.show();
				parent.addClass('open');
			}else{
				parent.addClass('hover');
			}
			$('.vH_DropDown').not(parent).removeClass('open');
			$('.vH_DropDown_Menu:visible').not(this_drop_menu).hide();
		}else{
			parent.removeClass('hover');
		}
		return false;
	});
});