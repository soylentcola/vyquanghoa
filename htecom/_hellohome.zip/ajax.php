<?php
	$do = $_REQUEST['do'];
	$sendData = json_decode(stripslashes($_REQUEST['sendData']));
	
	if($do == 'frm_login_dialog')
	{
		$html = <<<VH
		<div class="loginDialog dialogBox">
			<div class="dialogTitle up"><span class="txt">Đăng nhập <span class="sprite ico_lock" style="left:-35px; top:0"></span></span></div>
			<div class="dialogCt">
				<form action="" method="post" onsubmit="return checkLogin(this);">
				<table border="0" cellspacing="0" cellpadding="5" align="center">
					<tr>
						<td>
							<label class="label">Tên tài khoản hoặc Email:</label>
							<input type="text" class="inputtxt" />
						</td>
					</tr>
					<tr>
						<td>
							<label class="label">Mật khẩu:</label>
							<input type="text" class="inputtxt" />
						</td>
					</tr>
					<tr>
						<td>
							<input type="checkbox" class="check fl" />
							<label class="check_lbl">Duy trì đăng nhập</label>
							<div class="clr"></div>
							<button type="submit" class="subBtn" style="margin-top:20px;">Đăng nhập</button>
							<div style="padding:20px 0">&bull; <a href="">Bạn quên tài khoản đăng nhập hoặc mật khẩu?</a></div>
							<div style="font-size:16px;">Nếu bạn chưa có tài khoản Hellohome!  <a href="" do="register_dialog" data="" class="dialog under" rel="nofollow" title="">Đăng ký tài khoản</a></div>
						</td>
					</tr>
				</table>
				</form>
			</div>
		</div>
VH;
		echo $html;
	}
	//end frm_login_dialog
	
	if($do == 'frm_register_dialog')
	{
		$html = <<<VH
		<div class="dialogBox loginDialog registerDialog">
			<div class="dialogTitle up" style="padding-left:30px"><span class="txt">Tạo tài khoản HELLOHOME để có được nhiều lợi ích hơn <span class="sprite ico_lock" style="left:-35px; top:0"></span></span></div>
			<div class="dialogCt">
				<h3 style="margin-bottom:20px">Bạn có thể đăng nhập bằng nhiều cách khác nhau</h3>
				
				<div class="fl openidLs">
					<div style="padding-top:5px;">
						<div class="label">Đăng nhập bằng tài khoản Facebook</div>
						
						<div><img src="images/face-connect.png" width="238" height="46" /></div>
						<div style="line-height:20px; padding-top:15px">
							&bull; Chúng tôi chỉ chia sẻ những gì bạn chọn để chia sẻ<br />
							&bull;  Bạn sẽ xác định những gì được đăng tải lên Facebook
						</div>
						
					</div>
				</div>
				<div class="fr reg">
				<form action="" method="post" onsubmit="return checkRegister(this);">
					<table border="0" cellspacing="0" cellpadding="5" align="center">
						<tr>
							<td>
								<label class="label">Đăng ký bằng Email của bạn</label>
								<input type="text" class="inputtxt" />
							</td>
						</tr>
						<tr>
							<td>
								<button type="submit" class="subBtn" style="min-width:80px;">OK</button>
								<div style="line-height:20px; padding-top:15px">
									&bull; Chúng tôi không thích spam<br>
									&bull; Chúng tôi sẽ không chia sẻ email của bạn với bên thứ 3<br>
									&bull; Bạn có thể thay đổi tuỳ chọn email của bạn bất cứ lúc nào
								</div>
							</td>
						</tr>
					</table>
				</form>
				</div>
				<div class="clr"></div>
				<div style="padding-top:50px; font-size:16px; text-align:center">Nếu bạn có tài khoản Hellohome rồi! <a href="" do="login_dialog" class="dialog under" rel="nofollow" title="">Đăng nhập</a> ngay.</div>
			</div>
		</div>
VH;
		echo $html;
	}
	//end frm_register_dialog
?>