<?php
	//sleep(2);
	header('Content-type:images/jpg');
	readfile('pic/'.$_GET['file']);	
?>