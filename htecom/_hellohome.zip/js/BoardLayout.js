(function(){
	var c=this,e=c._,g={},
	f=Array.prototype,
	B=f.indexOf,
	
	n=function(p){return new R(p)};
	
	if(typeof exports!=="undefined"){
		if(typeof module!=="undefined"&&module.exports){
			exports=module.exports=n;exports._=n;
		}
	}else{
		c._=n;
	}
	n.VERSION="1.3.1";
	var z=n.each=n.forEach=function(p,w,y){
		if(p!=null){
			if(r&&p.forEach===r){
				p.forEach(w,y);
			}
		}else if(p.length===+p.length){
			for(var C=0,G=p.length;C<G;C++){
				if(C in p&&w.call(y,p[C],C,p)===g){
				return;
				}
			}
		}else{
			for(C in p){
				if(n.has(p,C)){
					if(w.call(y,p[C],C,p)===g){
						return;
					}
				}
			}
		}
	};
	
	n.indexOf=function(p,w,y){if(p==null)return-1;var C;
	if(y){y=n.sortedIndex(p,w);return p[y]===w?y:-1}if(B&&p.indexOf===B)return p.indexOf(w);y=0;for(C=p.length;y<C;y++)if(y in p&&p[y]===w)return y;return-1};
	
}).call(this);

var BoardLayout=function(){
	return{
		pinsContainer: '.BoardLayout',
		pinArray: [],
		orderedPins: [],
		columnCount: 3,
		columns:0,
		columnWidthInner: 234, /*width: 234px*/
		columnMargin: 15, /* == margin + (border left width | border right width)*/
		columnPadding: 0, /*padding: 0*/
		
		setup:function(b){			
			if(!this.setupComplete){
				this.setupFlow();
				this.setupComplete=true;
			}
		},

		setupFlow:function(b){
			if(!this.flowSetupComplete){
				BoardLayout.allPins();
				var _time = 0;
				/*b||$(window).resize(function(){
					clearTimeout(_time);
					_time = setTimeout('BoardLayout.allPins()',200);
				});*/
				this.flowSetupComplete=true;
			}
		},
		
		allPins:function()
		{
			var b=$(this.pinsContainer+" .pin"),c=this.getContentArea();
			this.columnWidthOuter=this.columnWidthInner+this.columnMargin+this.columnPadding;
			
			this.columns=Math.max(this.columnCount,parseInt(c/this.columnWidthOuter,10));
			
			
			if(b.length<this.columns){
				this.columns=Math.max(this.columnCount,b.length);
			}
				
			c=this.columnWidthOuter*this.columns-this.columnMargin;
			
			var e=document.getElementById("wrapper");
			if(e)e.style.width=c+"px";
			$(".LiquidContainer").css("width",c+"px");
			for(c=0;c<this.columns;c++)
				this.pinArray[c]=0;
				
			document.getElementById("SortableButtons")?this.showPins():this.flowPins(b,true);
			
			if($("#ColumnContainer .pin").length===0&&window.location.pathname==="/"){
				$("#ColumnContainer").addClass("empty");
				setTimeout(function(){window.location.reload()},5E3)
			}
		},
		
		getContentArea:function(){
			return 850;
			/*return this.contentArea||document.documentElement.clientWidth*/
		},
		
		flowPins:function(b,c){
			if(c){
				this.mappedPins={};
				this.orderedPins=[]
			}
			if(this.pinArray.length>this.columns)
				this.pinArray=this.pinArray.slice(0,this.columns);
			for(c=0;c<b.length;c++)
				this.positionPin(b[c]);
			this.updateContainerHeight();
			this.showPins();			
		},
		
		updateContainerHeight:function(){
			$("#ColumnContainer").height(Math.max.apply(Math,this.pinArray))
		},
		
		showPins:function(){
			$.browser.msie&&parseInt($.browser.version,10)==7||$(this.pinsContainer).css("opacity",1);
			var b=$(this.pinsContainer);
			setTimeout(function(){b.css({visibility:"visible"})},200);		
		},

		positionPin:function(b){
			var c=$(b).attr("data-id");
			
			if(c&&this.mappedPins[c]){
				$(b).remove();
			}else{
				var e=$(b).attr("data-force-col")?$(b).attr("data-force-col"):_.indexOf(this.pinArray,Math.min.apply(Math,this.pinArray));
				this.addPinToColumn(b,e);
				this.mappedPins[c]=this.orderedPins.length;
				this.orderedPins.push(c)
			}
		},
		
		addPinToColumn:function(b,c){
			var e=this.pinArray[c];
			b.style.top=e+"px";
			b.style.left=c*this.columnWidthOuter+"px";
			b.setAttribute("data-col",c);
			this.pinArray[c]=e+b.offsetHeight+this.columnMargin
		},
		
		rightMouse: function(){
			if($('.BoardLayout').hasClass('contextmenu')){
				$('.BoardLayout .pin .photo .pic').rightMouse({
					disabled:false,
					beforeStart: function(Context_Menu, elm)
					{
						var link_view = $('a',this).attr('data-href'),
						$ctext_open_link = $('<li>'),
						$ctext_add_to_ideabox = $('<li>');
						$ctext_open_link.html('Mở hình ảnh ở Tab mới').prepend($('<span>').attr('class','sprite s16 ico_open_window'));
						$ctext_add_to_ideabox.html('Thêm vào Ideabox').prepend($('<span>').attr('class','sprite s16 ico_confirm'));
						Context_Menu.append( $('<ul>').append($ctext_open_link, $ctext_add_to_ideabox));
						
						$($ctext_open_link).on('click',function(){
							window.open(link_view);	
						});
						
						$($ctext_add_to_ideabox).on('click',function(){
							alert('add to ideabox');
						});
					}
				});
			}
		}
	}
}();