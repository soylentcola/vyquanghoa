var config = {
	ajaxFile: 'ajax.php'
};

var delay = (function(){
	var timer = 0;
	return function(callback, ms){
		clearTimeout (timer);
		timer = setTimeout(callback, ms);
	};
})();

$(function(){
	if(typeof Cufon == "function"){
		Cufon.replace('.cufont',{hover:true});
	}
	jCore.onload();
	
	$('.Context_Menu li').live('mouseover mouseleave',function(e){
		if(e.type == 'mouseover'){
			$(this).addClass('hover');
		}else{
			$(this).removeClass('hover');
		}
	});
	
	/*process bar*/
	var $perBar = $('.perBar');
	if($perBar.size() > 0){
		var $perBar_w = $perBar.width(),
		$per = $('.per',$perBar),
		per = Number($per.attr('per'));
		
		if(typeof per == "number" && !isNaN(per)){
			$per.css('width',$perBar_w*(per/100));
		}
	}
	
	/* profile avatar*/
	var $profileAvatar = $('.profileBox .avatar'), $img = $('img', $profileAvatar);
	if($profileAvatar.size() >0){
		var position = jCore.thumbImg($profileAvatar.width(), $profileAvatar.height(), $img);
		$img.css({
			top: position.y,
			width: position.w,
			height: position.h
		});
		if(position.x < 0){
			$img.css({
				left: position.x
			});
		}
	}
	
	/* dialog*/
	$('.dialog').live('click',function(){
		var _do = $.trim($(this).attr('do')),
		data = $.trim($(this).attr('data')),
		send_data='';
		
		if(data != "")
			send_data = {sendData:data};
		
		if(_do != ""){
			$.get(config.ajaxFile+'?do=frm_'+_do,send_data,function(data){
				$().vhbox({
					html: data	
				});
			});
			return false;
		}
	});
	/*$('img').rightMouse();*/
	
});





var jCore = function()
{
	return{
		scrollTop:0,
		hdrHeight:0,
		
		onload: function()
		{
			this.log('call onload');			
			/*window.oncontextmenu = function(){
				return false;
			}*/
			this.slideShowFullScreen();
			
			this.hdrHeight = $('.hdr').height();
			if(typeof $.fn.vH_SelectStyle == "function")
			{
				$('select.select_style').vH_SelectStyle({
					width: 100,
					style: true
				});
			}
			
			$('.homepageSectionCategories').live('mouseover mouseleave',function(e){
				if(e.type == 'mouseover'){
					$(this).addClass('hover');
				}else{
					$(this).removeClass('hover');
				}
			});
			
			$(window).bind('scroll',function(){
				jCore.scrollTop = $(this).scrollTop();
				jCore.setNavPosition();
			});			
			
			$(document).scrollTop($(window).scrollTop()+1);
			$(document).scrollTop($(window).scrollTop()-1);
			
		},
		
		setNavPosition:function()
		{
			/*this.log('call setNavPosition');*/
			var scrollTop = jCore.scrollTop||$(window).scrollTop();
			
			var nav_pos, nav_logo, _class, $nav_pos = $('.navbar .pos');
			if(scrollTop >= this.hdrHeight)
			{
				$nav_pos.css('position','fixed');
				$('body').addClass('scroll');
				$('.mc').css('padding-top',$nav_pos.outerHeight()+11);
				
				if($('.navbar li.home').is(':hidden')){
					$('.navbar li.home').show();/*.animate({width:'show'});*/
				}
				$('.navbar .search, .navbar .upload_btn').show();
				
			}else{
				$nav_pos.css('position','');
				$('.navbar li.home').hide();/*animate({width:'hide'});*/
				$('body').removeClass('scroll');
				$('.mc').css('padding-top',11);				
				$('.navbar .search, .navbar .upload_btn').hide();
			}
		},
		
		slideShowFullScreen: function()
		{
			this.log('call slideShowFullScreen');
			
			var viewFullScreen = document.getElementById('test');
			if (viewFullScreen) {
				viewFullScreen.addEventListener("click", function () {
					/*var docElm = document.documentElement;*/
					var docElm = document.getElementById('slideshowContainer'); /*chi phan nay*/
					if (docElm.requestFullscreen){
						docElm.requestFullscreen();
					}
					else if (docElm.mozRequestFullScreen) {
						docElm.mozRequestFullScreen();
					}
					else if (docElm.webkitRequestFullScreen) {
						docElm.webkitRequestFullScreen();
					}
				}, false);
			}
		},		
		
		thumbImg: function(frm_width, frm_height, img)
		{			
			frm_width = Number(frm_width), frm_height = Number(frm_height);
			if(isNaN(frm_width) || isNaN(frm_height) || typeof img != "object"){
				this.log('thumbImg() input error');
				return false;
			}
			img.css({width:'auto',height:'auto'}).removeAttr('width height');
			var img_width = img.attr('data-width'), img_height = img.attr('data-height');
		
			 /*img position top*/
			var img_pos_top = (frm_height - img_height)/2;
			
			 /*img position left*/
			var img_pos_left = (frm_width - img_width)/2;
			
			/*img.css({
				marginTop: img_pos_top,
				marginLeft: img_pos_left
			});*/
			var $return = {'w':img_width, 'h':img_height, 'x': img_pos_left, 'y': img_pos_top};
			return $return;
		},
		
		keyCode: function(e)
		{
			var charCode = e.which || e.keyCode;
			return charCode;
		},
		
		log: function(msg){
			if(window.console){
				console.log(msg);
			}
			return;
		},
		warn: function(){
			if(window.console){
				console.warn(msg);
			}
			return;
		}
	}
}();

function checkLogin(frm){
	alert('checkLogin() - jCore.php');
	return false;
}

function checkRegister(frm){
	alert('checkRegister() - jCore.php');
	return false;
}