$(function(){
	jMain.onload();
});

var jMain = function()
{
	return{
		stop:true,
		remove_class:false,
		SlideshowPhotos: "#slideshowContainer .SlideshowPhotos",
		
		onload: function()
		{		
			jMain.createSlideShow();
			
			/* photo context menu */
			$('#slideshowContainer').rightMouse({
				disabled:false,
				beforeStart: function(Context_Menu, elm)
				{
					var curr = $(jMain.SlideshowPhotos).jCarouselLite.curr(),
					photo_url = $(curr).attr('data-href'),
					
					$ctext_open_link = $('<li>'),
					$ctext_add_to_ideabox = $('<li>'),
					$next_photo = $('<li>'),
					$prev_photo = $('<li>'),
					$fullscreen = $('<li>');
					
					$ctext_open_link.html('Mở hình ảnh ở Tab mới').prepend($('<span>').attr('class','sprite s16 ico_open_window'));
					$ctext_add_to_ideabox.html('Thêm vào Ideabox').prepend($('<span>').attr('class','sprite s16 ico_confirm'));
					$next_photo.html('Ảnh sau').prepend($('<span>').attr('class','sprite s16 slide_next'));					
					$prev_photo.html('Ảnh trước').prepend($('<span>').attr('class','sprite s16 slide_prev'));
					
					if($(jMain.SlideshowPhotos).jCarouselLite.first()){
						$prev_photo.addClass('disabled');
						
					}else if($(jMain.SlideshowPhotos).jCarouselLite.last()){
						$next_photo.addClass('disabled');
					}
					Context_Menu.append( $('<ul>').append($ctext_open_link, $ctext_add_to_ideabox, $prev_photo, $next_photo, $fullscreen));					
					
					/* fullscreen*/
					var fullscreen = false;
					if(!jMain.checkFullScreenMod()){
						$fullscreen.html('Xem chế độ toàn màn hình');
					}else{
						$fullscreen.html('Thoát chế độ toàn màn hình');
					}
					$fullscreen.prepend($('<span>').attr('class','sprite s16 ico_fullscreen'));
					$($fullscreen).on('click',function(){
						if(jMain.checkFullScreenMod()){
							jMain.exitFullScreen();
						}else{
							jMain.fullscreen();
						}
					});
					
					/* mo hinh anh o tab moi*/
					$($ctext_open_link).on('click',function(){
						window.open(photo_url);
					});
					
					/* them hinh anh vao ideabox*/
					$($ctext_add_to_ideabox).on('click',function(){
						alert('Thêm vào Ideabbox');
					});
					
					/* anh sau */
					$($next_photo).on('click',function(){
						if(!$(this).hasClass('disabled')){
							var index = $('li',$(jMain.SlideshowPhotos)).index($(jMain.SlideshowPhotos).jCarouselLite.curr());
							$(jMain.SlideshowPhotos).jCarouselLite.next(index);
						}
					});
					
					/* anh truoc */
					$($prev_photo).on('click',function(){
						if(!$(this).hasClass('disabled')){
							var index = $('li',$(jMain.SlideshowPhotos)).index($(jMain.SlideshowPhotos).jCarouselLite.curr());
							$(jMain.SlideshowPhotos).jCarouselLite.prev(index);
						}
					});
					
					
					
					return false;
				}	
			});
			
			/*console.log($(jMain.SlideshowPhotos));*/
			$("#slideshowContainer .SlideshowPhotos .sl_move_elm").live('click',function(e){
				e.stopPropagation();
				var curr = $(jMain.SlideshowPhotos).jCarouselLite.curr();
				var index = $("#slideshowContainer .SlideshowPhotos li").index(curr);
				if(!$(this).hasClass('disabled'))
				{
					if($(this).hasClass('elm_prev'))
					{
						$(jMain.SlideshowPhotos).jCarouselLite.prev(index);
					}else{
						$(jMain.SlideshowPhotos).jCarouselLite.next(index);
					}
				}
			});
			
			/*bam vao anh de next*/
			$("#slideshowContainer .SlideshowPhotos img").live('click',function(){
				var index = $("#slideshowContainer .SlideshowPhotos li").index($("#slideshowContainer .SlideshowPhotos img").jCarouselLite.curr());
				$("#slideshowContainer .SlideshowPhotos img").jCarouselLite.next(index);
			});
			
			
			/*thong tin nguoi dang anh*/
			var slideshowInfoSpot = $('.slideshowInfoSpot'), slideshowInfoSpot_height, height_ = 538;
			slideshowInfoSpot_height = slideshowInfoSpot.height();
			
			$('.slideshowInfoSpotTrimmed').live('click',function()
			{
				var this_ = this;
				if($('.categoriesBtn').hasClass('open')){
					return false;
				}
					
				/*console.log(slideshowInfoSpot_height);*/
				if(slideshowInfoSpot.hasClass('show')){
					_height_ = slideshowInfoSpot_height;
					jMain.remove_class = true;
					$('.slideshowInfo',slideshowInfoSpot).hide();
				}else{
					_height_ = height_;
				}
					
				if(jMain.stop == true)
				{
					jMain.stop = false;
					slideshowInfoSpot.animate({
						height: _height_
					},200,function(){
						jMain.stop = true;
						if(jMain.remove_class){
							slideshowInfoSpot.removeClass('show');
							jMain.remove_class = false;
							$('.slideshowInfoButton',this_).removeClass('ico_arrup').addClass('ico_arrdown');
						}else{
							slideshowInfoSpot.addClass('show');
							$('.slideshowInfo',slideshowInfoSpot).slideDown(300);
							$('.slideshowInfoButton',this_).removeClass('ico_arrdown').addClass('ico_arrup');
						}
					});
				}
			});
			
			/*===============*/
			$('.slideshowInfoSpot').live('dblclick',function(){
				if(slideshowInfoSpot.hasClass('show')){
					$('.slideshowInfoSpotTrimmed').trigger('click');
				}
			});
			
			
			/*load anh dau tien cua slide*/
			$("#slideshowContainer .SlideshowPhotos img.photo:first").load(function(){
				$("#slideshowContainer .SlideshowPhotos .loading").hide();
			});
			
			
			/* chon chuyen muc */
			var stop = true;
			$('.categoriesBtn').live('click',function(e)
			{
				/*var slide_curr = $("#slideshowContainer .SlideshowPhotos img").jCarouselLite.curr();*/
				var _this = $(this);
				var slideshowInfoSpot_show = $('.slideshowInfoSpot').hasClass('show');
				var slideshowInfoSpot_cat_show = $('.slideshowInfoSpot').hasClass('cat_show');
				
				if(stop == true)
				{
					stop = false;
					
					if(_this.hasClass('open')){/*neu dang mo*/
						_this.removeClass('open');
						
						/*hien thi thong tin nguoi dang*/
						if(slideshowInfoSpot_cat_show){
							$('.slideshowInfoSpotTrimmed').trigger('click');
							$('.slideshowInfoSpot').removeClass('cat_show');
						}
						/*an danh sach chuyen muc*/
						$('.dropdown_categories').animate({height:'hide'},200,function(){
							stop = true;							
						});
						/*hien thi thong tin hinh anh*/
						$("#slideshowContainer .SlideshowPhotos .photo_info").slideDown(200);
						
						
					}else{/*neu dang dong*/
						
						/*an thong tin nguoi dang*/
						if(slideshowInfoSpot_show){
							$('.slideshowInfoSpotTrimmed').trigger('click');
							$('.slideshowInfoSpot').addClass('cat_show');
						}
							
						/*hien thi danh sach chuyen muc*/
						$('.dropdown_categories').animate({height:'show'},200,function(){
							stop = true;
						});
						
						/*an thong tin hinh anh*/
						$("#slideshowContainer .SlideshowPhotos .photo_info").slideUp(200);
						
						_this.addClass('open');
					}
				}
				return false;
			});
			
			/*xem toan man hinh*/
			$('.fullScreenBtn').live('click',function(){
				if(!jMain.checkFullScreenMod()){					
					jMain.fullscreen();
				}else{					
					jMain.exitFullScreen();					
				}
				return false;
			});
			
			$(document).bind('keyup',function(e){
				if(jCore.keyCode(e) == 27){
					if(jMain.checkFullScreenMod()){
						jMain.exitFullScreen();
					}
				}
			});
			
			$(window).bind('resize',function(){
				delay(function(){
					jMain.setSlideSize();
				},200);
				return false;
			});
			
			/* ============= */
			$('.SlideshowControls .slide_btn').live('click',function()
			{
				var curr_slide = $("li",$(jMain.SlideshowPhotos)).index($(jMain.SlideshowPhotos).jCarouselLite.curr());
				/*console.log(curr_slide);*/
				
				if($(this).hasClass('slide_prev')){
					$(jMain.SlideshowPhotos).jCarouselLite.prev(curr_slide);
				}else if($(this).hasClass('slide_next')){
					$(jMain.SlideshowPhotos).jCarouselLite.next(curr_slide);
				}
			});
		},
		
		createSlideShow :function(start_){
			$(jMain.SlideshowPhotos).jCarouselLite({
				/*btnNext: ".SlideshowControls #ss_next",*/
				/*btnPrev: ".SlideshowControls #ss_prev",*/
				circular: false,
				visible:1,
				start: start_||0,
				scroll:1,
				beforeStart: function(_item){
					jMain.updateSlideControl(_item,true);
				},
				afterEnd: function(_item){
					jMain.updateSlideControl(_item,false);
				}
			});
		},
			
		fullscreen: function()
		{
			$('.fullScreenBtn .txt').html('Thoát c.độ toàn màn hình');
			var fullscreen = $('div#fullscreen');
			if(fullscreen.size() == 0){
				$('.mc').prepend($('<div>').attr({'id':'fullscreen','class':'slideshowContainer_fullscreen'}));
			}else{
				$('#fullscreen').show();
			}
			
			/*=============*/
			var $slideshowContainer = $('#slideshowContainer').addClass('ss_fullscreen');
			$slideshowContainer.appendTo('#fullscreen');
			
			/*=============*/
			$('body').css({
				overflow:'hidden'
			});
			
			jMain.setSlideSize();
				
			return false;
		},
		
		exitFullScreen: function()
		{
			var $slideshowContainer = $('#slideshowContainer');
			$('.fullScreenBtn .txt').html('Toàn màn hình');
			
			jMain.setSlideSize(true);
			$slideshowContainer.appendTo('#slideshow_frm');
			$('#fullscreen').hide();
			$slideshowContainer.removeClass('ss_fullscreen');
			$('body').css({
				overflow:''
			});
			
		},
		
		setSlideSize: function(exit)
		{
			var LI_SlideshowPhotos_css, 
			dropdown_categories, 
			SlideshowControls = $("#slideshowContainer .SlideshowControls"), 
			win_height = $(window).height(),
			win_width = $(window).width();
			
			if(jMain.checkFullScreenMod())
			{
				var curren_slide_item = $(jMain.SlideshowPhotos).jCarouselLite.curr();
				var slide_index = $("#slideshowContainer .SlideshowPhotos li").index(curren_slide_item);
				
				if(exit == true){
					/* tro ve man hinh mac dinh */
					item_inner = {
						height:500,
						width: 1014
					};
					dropdown_categories = {left:572};
				}else{
					
					/*che do fullscreen*/
					item_inner = {
						height: (win_height-SlideshowControls.height()),
						width: win_width
					};
					dropdown_categories = {left:$('.categoriesBtn',SlideshowControls).offset().left};
				}
				$('.slideshowContainer .SlideshowControls .dropdown_categories').css(dropdown_categories);
				
				$("#slideshowContainer .SlideshowPhotos li .item_inner").css(item_inner);
				$(jMain.SlideshowPhotos).removeAttr('style').css(item_inner);
				$("#slideshowContainer .SlideshowPhotos ul").removeAttr('style');
				$("#slideshowContainer .SlideshowPhotos li").removeAttr('style').css(item_inner);
				$('.slideshowContainer .SlideshowPhotos .loading').css(item_inner);
				
				
				/*setup slideshow*/
				$(jMain.SlideshowPhotos).jCarouselLite.destroy();
				$(jMain.SlideshowPhotos).jCarouselLite = null;
				
				delay(function(){
					jMain.createSlideShow(slide_index);
					jMain.setImgPosition();
				},200);
			}
		},
		
		checkFullScreenMod: function(){
			var $slideshowContainer = $('#slideshowContainer');
			if($slideshowContainer.hasClass('ss_fullscreen')){
				return true;
			}else{
				return false;
			}
		},
		
		setImgPosition: function()
		{
			var curr_slide = $(jMain.SlideshowPhotos).jCarouselLite.curr();
			var curr_slide_img = $('img.photo',curr_slide);
			var position = jMain.thumbImg(curr_slide.width(), curr_slide.height(), curr_slide_img, $('.photo_info',curr_slide).height());
			curr_slide_img.css({
				top: position.y,
				width: position.w,
				height: position.h
			});
			if(position.x < 0){
				curr_slide_img.css({
					left: position.x
				});
			}
			return;			
		},
		
		
		thumbImg: function(frm_width, frm_height, img, photo_info_height)
		{			
			frm_width = Number(frm_width), frm_height = Number(frm_height);
			if(isNaN(frm_width) || isNaN(frm_height) || typeof img != "object"){
				this.log('thumbImg() input error');
				return false;
			}
			img.css({width:'auto',height:'auto'}).removeAttr('width height');
			var img_width = img.attr('data-width'), img_height = img.attr('data-height');
			
			photo_info_height = Number(photo_info_height);
			
			if(!isNaN(photo_info_height) && photo_info_height > 0){
				if((frm_height-photo_info_height) >= img_height){
					frm_height = frm_height-photo_info_height;
				}
			}
			 /*img position top*/
			var img_pos_top = (frm_height - img_height)/2;
			
			 /*img position left*/
			var img_pos_left = (frm_width - img_width)/2;
			
			/*img.css({
				marginTop: img_pos_top,
				marginLeft: img_pos_left
			});*/
			var $return = {'w':img_width, 'h':img_height, 'x': img_pos_left, 'y': img_pos_top};
			return $return;
		},
		
		updateSlideControl: function(_item, start)
		{
			$("#slideshowContainer .SlideshowControls .slide_btn").attr('disabled',false).removeClass('disabled');
			
			if($(jMain.SlideshowPhotos).jCarouselLite.last()){
				$("#slideshowContainer .SlideshowControls .slide_next").attr('disabled',true).addClass('disabled');
				
			}else if($(jMain.SlideshowPhotos).jCarouselLite.first()){
				$("#slideshowContainer .SlideshowControls .slide_prev").attr('disabled',true).addClass('disabled');
			}
			
			/*var jtest = $.post('img.php');
			jtest.abort();*/
			
			if(start){
				$('.photo',_item).unbind('load');
				$("#slideshowContainer .SlideshowPhotos .loading").hide();
			}else{
				$("#slideshowContainer .SlideshowPhotos .loading").show();
				var img = $('.photo',_item);
				var img_src = img.attr('src');
				var data_src = img.attr('data-src');
				if(img_src == "" || img_src == "undefined" || img_src == undefined){
					jMain.setImgPosition();
					img.attr('src',data_src).load(function(){
						$("#slideshowContainer .SlideshowPhotos .loading").hide();						
					});
				}else{
					$("#slideshowContainer .SlideshowPhotos .loading").hide();
					jMain.setImgPosition();
				}
			}
		}
	};
}();