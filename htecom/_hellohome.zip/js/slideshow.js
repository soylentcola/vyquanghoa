var SlideShow = function(){
	var _this,
	$Root,
	$Overlay,
	$Close,
	$Header, 
	$Image,
	$Anchors,
	$Actions,
	$ActionsLeft,
	$ActionsCenter,
	$ActionsRight,
	$ImageViewLayer,
	$NavigationLayer,
	$TrackingIframe,
	$window;
	
	return{
		prefix: 'vDialog_',
		
		setup:function()
		{
			_this = this;
			
			$window = $(window),
			$Root = this.$tag('div', 'Root'),
			$Overlay = this.$tag('div', 'Overlay');
			
			$Root.append(
				$Header = this.$tag('div','Header'),
				$Close = this.$tag('a','Close').attr('href','javascript:;'),
				$Image = this.$tag('div','Image').append(
					$Actions = this.$tag('div','Actions').append(
						this.$tag('tr').append(
							$ActionsLeft = this.$tag('td','ActionsLeft'),
							$ActionsCenter = this.$tag('td','ActionsCenter'),
							$ActionsRight = this.$tag('td','ActionsRight')
						)
					),
					$ImageViewLayer = this.$tag('div','ImageViewLayer'),
					$NavigationLayer = this.$tag('div','NavigationLayer').append(
						this.$tag('div','NavigationLeft').append(this.$tag('span','NavigationLeftArrow')),
						this.$tag('div','NavigationRight').append(this.$tag('span','NavigationRightArrow'))
					),
					$TrackingIframe = this.$tag('div','TrackingIframe').append(this.$tag('iframe'))
				),
				$Anchors = this.$tag('div','Anchors'),
				$InfoScroller = this.$tag('div','InfoScroller')
			);
			
			$(document.body).append($Root.hide(),$Overlay.hide());
			
			
			$(window).bind('resize',function(){
				if(this.resize_)
					clearTimeout(resize_);
				this.resize_ = setTimeout(function(){
					$(this).trigger('resizeEnd');	
				},100);
					
			}).bind('resizeEnd',function(){
				_this.setSize();
			});
		},
		
		show: function(){
			$('body').addClass('slideShow');
			$Root.show();
			$Overlay.show();
			this.setSize();
		},
		
		close: function(){
			$('body').removeClass('slideShow');
		},
		
		setSize: function(){
			var			
			window_width = $window.width(),
			window_height = $window.height(),
			dialog_width = window_width-80,
			dialog_height = window_height-80;
			
			dialog_width = (dialog_width<726) ? 726 : dialog_width;
			dialog_height = (dialog_height<484) ? 484 : dialog_height;
			$Root.css({
				width: dialog_width,
				height:	dialog_height
			});
			
			console.log('a'+dialog_width);
		},
		
		$tag: function (tag, id, css){
			var element = document.createElement(tag);
		
			if (id) {
				element.id = this.prefix + id;
			}
		
			if (css) {
				element.style.cssText = css;
			}
		
			return $(element);
		},
		
		test: function(){
			console.log($Root);	
		}
		
	}
}(jQuery);

$(function(){
	SlideShow.setup();
	SlideShow.show();
});