(function($){
    $.fn.extend({
		
		vH_SelectStyle: function(o){
			var defaults = {
				prefix: 'selectStyle_',
				useStyle: true
			};
            var o = $.extend(defaults, o);
			
			return this.each(function(i){
				var obj = $(this);
				
				var $div = $('<div id="'+o.prefix+i+'">').attr({
					'class': o.prefix	+'Elm'					
				});
				if(o.useStyle){
					$div.attr('style', obj.attr('style'));
				}
				var $txt = $('<span>').attr('class',o.prefix+'Txt').html($(':selected',obj).text());
				var $arrow = $('<span>').attr('class',o.prefix+'Arrow');
				
				$div.append($txt, $arrow);
				obj.removeAttr('style').fadeTo(1,0).after($div).appendTo($div);
				
				obj.live('change',function(e){
					var t = $(':selected',this).text();
					$txt.html(t);
					$div.attr('title',t);
				});
            });
		}
		
       , vH_Tabs: function(o){
			var defaults = {
				change: null,
				beforeChange: null, /*beforeChange:function(curr_tab, curr_tab_ct){...}*/
				afterChange: null, /*afterChange:function(curr_tab, curr_tab_ct){...}*/
				selectedClass: 'ActiveTab',
				parentTabs: '.vH_Tabs', /*class or id of ul tabs*/
				tabContent: 'vH_Tabs_Content', /*class of tab content*/
				hover: false, /* mouseover event*/
				start: 1,
				tabCtLink: 'rel' /* <a href="..." rel="..." title="title">tab 1</a>*/
			};
             
            var o = $.extend(defaults, o);
         
            return this.each(function()
			{      
				var obj = $(this),
				ulTabs = $(o.parentTabs, obj),
				tabLength = $('li',ulTabs).size(),				
				event_ = o.hover ? 'mouseover' : 'click',
				tab_ct,
				curr_tab_ct;
				
				$('li',ulTabs).each(function(i)
				{
					tab_ct = $('a',this).attr(o.tabCtLink);
					$(tab_ct,obj).addClass(o.tabContent);
					
					if(o.start > 0 && o.start <= tabLength){
						if((i+1) != o.start){
							$(tab_ct, obj).hide();
						}else{
							curr_tab_ct = $(this, ulTabs);
						}
					}else{
						 if(i > 0){
							$(tab_ct, obj).hide();
						 }else{
							 curr_tab_ct = $(this, ulTabs);
						 }
					}
					curr_tab_ct.addClass(o.selectedClass);
				});
				
				/*tab event*/
				$('a',ulTabs).on(event_,function(e)
				{
					/*e.preventDefault();*/
					e.stopPropagation();
					
					if(o.beforeChange){
						o.beforeChange.call(this, $('li.'+o.selectedClass,ulTabs), $('.'+o.tabContent+':visible',obj));
					}
					/*active this tab*/
					var li_tab = $(this).parent('li');
					li_tab.addClass(o.selectedClass);
					$('li',ulTabs).not(li_tab).removeClass(o.selectedClass);
					
					/* show tab content */
					tab_ct = $($(this).attr(o.tabCtLink),obj);
					tab_ct.show();
					
					$('.'+o.tabContent, obj).not(tab_ct).hide();
					
					if(o.afterChange){
						o.afterChange.call(this, li_tab, tab_ct);
					}
					return false;
				});
            });
        }
		
		,rightMouse: function(o){
			var defaults = {
				escKey: true,
				beforeStart:null,
				disabled:true
			};
             
            var o = $.extend(defaults, o);
         
            return this.each(function()
			{      
				var obj = $(this);
				
				function Add_Context_Menu_Frm()
				{
					var Context_Menu = $('div.Context_Menu');
					if(Context_Menu.size() == 0){
						$('body').append($('<div>').attr('class','Context_Menu'));
					}
					Context_Menu.show();
					return $('.Context_Menu');
				};
				
				function Context_Menu_Hide(){
					$('.Context_Menu').empty().hide();
				}
				
				obj[0].oncontextmenu = function(e)
				{
					if(o.disabled)
						return false;
						
					var Context_Menu = Add_Context_Menu_Frm();
					Context_Menu.empty().disableTextSelect();
					
					if(o.beforeStart){
						o.beforeStart.call(this,Context_Menu,$(e.target));
					}
					
					e.stopPropagation();
					var elm = $(e.target),
					$window = $(window),
					menu_pos_left = e.pageX,
					menu_pos_top = e.pageY;

					if((menu_pos_left+Context_Menu.width()) >= $window.width()){
						menu_pos_left = ($window.width()-Context_Menu.width());
						menu_pos_left = menu_pos_left-10;
					}
					
					/*if((menu_pos_top+Context_Menu.height()) >= $window.height()){
						menu_pos_top = ($window.height()-Context_Menu.height());
						menu_pos_top = menu_pos_top-10;
					}*/
					
					Context_Menu.css({
						top: menu_pos_top,
						left: menu_pos_left
					});
					return false;
				};
				
				if(o.escKey){
					$(document).bind('keydown',function(e){
						var charCode = e.which || e.keyCode;
						if(charCode == 27){
							Context_Menu_Hide();
							return false;
						}
					});
					
				};
				
				$(document).on('click',function(e){
					var charCode = e.which || e.keyCode;
					var elm = $(e.target);
					if(charCode == 1){
						if(!elm.hasClass('Context_Menu')){
							if(elm.parents('.Context_Menu').size() == 0){
								Context_Menu_Hide();
							}else{
								if(!elm.hasClass('disabled')){
									Context_Menu_Hide();
								}
							}
						}
					}else{
						if(elm.parents('.Context_Menu').size() > 0){
							e.stopPropagation();
							return false;
						}else{
							Context_Menu_Hide();
						}
					}
				});
			});
		}
		
		,enableTextSelect: function(){
			if ($.browser.mozilla) {
				return this.each(function() {
					$(this).css({
						'MozUserSelect' : ''
					});
				});
			}else if ($.browser.msie) {
				return this.each(function() {
					$(this).unbind('selectstart.disableTextSelect');
				});
			} else {
				return this.each(function() {
					$(this).unbind('mousedown.disableTextSelect');
				});
			}
		}
		
		,disableTextSelect: function(){
			if ($.browser.mozilla) {
				return this.each(function() {
					$(this).css({
						'MozUserSelect' : 'none'
					});
				});
			}else if ($.browser.msie) {
				 return this.each(function() {
					$(this).bind('selectstart.disableTextSelect', function() {
						return false;
					});
				});
			} else {
				 return this.each(function() {
					$(this).bind('mousedown.disableTextSelect', function() {
						return false;
					});
				});
			}
		}
		
		/*,vH_Dialog: function(o){
			var defaults = {
			};             
            var o = $.extend(defaults, o);
         
            return this.each(function()
			{
			});
		 }*/

    });
})(jQuery);