<?php
	var_dump(connection_status());
	die();

	set_time_limit (0);//run script forever
	ignore_user_abort();//run script in background
	$i = 0;
	echo "start\n";
	while (1){
		$i++;
		echo $i, "\n";
		$sleep = sleep(1);
		if($i == 20)
			die();
		else{
			$a = fopen('_test/a_'.time().'.txt','w+');
			fputs($a,time());
			fclose($a);
		}
		if ($sleep == 0 or $sleep or $sleep == FALSE)
			continue;
		if (connection_aborted())
			continue;
		if (connection_status () != 0)
			continue;	
	}
?> 