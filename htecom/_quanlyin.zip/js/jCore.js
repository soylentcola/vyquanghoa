var VHC = VHC || {};
//see http://phpjs.org/functions/

//========================================= utils 
VHC.utils = {
	notice: function(msg, settings)
	{
		try{
			var defaults = {
				title: 'Thông báo',
				confirm: false,
				buttons: {
					'close': {
						html: 'Đóng',
						click: function(){
							$().colorbox.close();
						}
					}	
				}
			};
			var settings_ = $.extend({}, defaults, settings);
			
			if(settings_.confirm && !settings.title)
				settings_.title = 'Xác nhận';
				
			$().colorbox({
				html: '<div id="cboxError">'+msg+'</div>',
				title: settings_.title,
				buttons: settings_.buttons
			});
			
		}catch(err){
			alert( err);
		}
	},
	
	fakeClick: function(event, anchorObj)
	{
		if(event.type == "submit"){
			$('input:submit',anchorObj).trigger('click');
			return;
		}
		
		if (anchorObj.click)
		{
			anchorObj.click();
			
		} else if(document.createEvent) 
		{
			if(event.target !== anchorObj)
			{
				var evt = document.createEvent("MouseEvents"); 
				evt.initMouseEvent(event.type, true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null); 
				var allowDefault = anchorObj.dispatchEvent(evt);
			}
		}
	},

	confirm: function(msg, e, event)
	{
		//onsubmit="(VHC.utils.confirm('Co muon di khong?', this, event)); return false;"
		//onclick="(VHC.utils.confirm('Co muon di khong?', this, event));return false;"
		var nodeName = event.target.nodeName;
		
		var options = {
			confirm: true,
			buttons:{
				'confirm': {
					html: 'Xác nhận',
					class: 'confirm',
					click: function(){
						$().colorbox.close();
						$(document).bind('cbox_closed',function(){
							$(e).removeAttr('onclick').removeAttr('onsubmit');
							var $new_elm = $('<input type="button">')
							.attr({
								onclick: function(){
									VHC.utils.fakeClick(event, e);	
								}
							}).hide();
							$('body').append($new_elm);
						});
					}
				},
				
				'cancel': {
					html: 'Hủy',
					click: function(){
						$().colorbox.close();
					}
				}
			}
		}
		VHC.utils.notice(msg,options);
		return false;
	},
	
	checkAll: function(_this, checkname)
	{
		var checked = _this.checked;
		if(checkname == undefined || checkname == "undefined"){
			checkname = 'checkbox';
		}
		$('input[name="'+checkname+'[]"]',$(_this).parents()).each(function(){
			$(this).attr('checked',checked);
			if(checked ==true){
				$(this).parents('tr:not(.head)').addClass('selected');
			}else{
				$(this).parents('tr:not(.head)').removeClass('selected');
			}
		});
		return '';
	},
	
	checkOne: function(_this, checkname)
	{
		var checked = _this.checked;
		if(checkname == undefined || checkname == "undefined"){
			checkname = 'checkbox';
		}
		var checkbox_size = $(_this).parents('table.tborder').find('input[name="'+checkname+'[]"]').size();
		var checked_size = $(_this).parents('table.tborder').find('input[name="'+checkname+'[]"]:checked').size();
		var tr_parent = $(_this).parents('tr:not(.head)');
		
		if(checked==false){
			checked_size+=1;
			tr_parent.addClass('selected');
		}else{
			tr_parent.removeClass('selected');
			checked_size-=1;
		}
			
		var checkall = $(_this).parents('table.tborder').find('input.checkall');
		if(checked_size == checkbox_size){
			checkall.attr('checked',true);
		}else{
			checkall.attr('checked',false);
		}
		return '';
		
	},
	
	tborder: function()
	{
		$('.tborder td input[name*="checkbox"]').live('click',function(e){
			e.stopPropagation();
		});
		
		$('.tborder td').live('mousedown',function(e){
			e.stopPropagation();
			var tr_parent = $(this).parent('tr:not(.head)');
			$('input:checkbox',tr_parent).trigger('click');
		});
		
		
	},
	
	getCookie: function (name)
	{
		console.log(document.cookie);
		var start = document.cookie.indexOf(name+"=");
		var len = start+name.length+1;
		if ((!start) && (name != document.cookie.substring(0,name.length))) return null;
		if (start == -1) return null;
		var end = document.cookie.indexOf(";",len);
		if (end == -1) end = document.cookie.length;
		return unescape(document.cookie.substring(len,end));
	},
	
	setCookie: function (name,value,expires2,path,domain) 
	{
		if(!expires2)
			expires2 = 24;
		var expires = new Date();
		expires.setTime(expires.getTime() + expires2*60*60*60*500);
		document.cookie = name + "=" + escape(value) + "; expires=" +
			((expires) ? expires : 0) +
			((path) ? "; path=" + path : "") +
			((domain) ? "; domain=" + domain : "");
	},
	
	deleteCookie: function(name,path,domain) 
	{
		if (VHC.utils.getCookie(name)) document.cookie = name + "=" +
		   ( (path) ? ";path=" + path : "") +
		   ( (domain) ? ";domain=" + domain : "") +
		   ";expires=Thu, 01-Jan-70 00:00:01 GMT";
	},
	
	getUrlVars: function()
	{
		var vars = [], hash;
		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
			
		for(var i = 0; i < hashes.length; i++)
		{
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
												
		return vars;
	},
		
	validateEmail: function(emailString, allowMultiple)
	{
		var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  // see: 
		var strings = [emailString];
		if (allowMultiple) {
			var strings = emailString.split(",");
		}
		var valid = false;
		for (var i=0; i<strings.length; i++) {
			var str = VHC.utils.trim(strings[i]);
			if (str) {
				if (!emailPattern.test(str))
					return false;
				else
					valid = true;
			}
		}
		return valid;
	},
	
	trim:function(str){
		return str.replace(/^\s+|\s+$/g,"");
	},
	
	ucwords:function(str) {
		// see: http://phpjs.org/functions/ucwords:569
		return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
			return $1.toUpperCase();
		});
	},
	
	md5: function( str )
	{
		// see: http://phpjs.org/functions/md5:469
		var xl;
	
		var rotateLeft = function (lValue, iShiftBits) {
			return (lValue << iShiftBits) | (lValue >>> (32 - iShiftBits));
		};
	
		var addUnsigned = function (lX, lY) {
			var lX4, lY4, lX8, lY8, lResult;
			lX8 = (lX & 0x80000000);
			lY8 = (lY & 0x80000000);
			lX4 = (lX & 0x40000000);
			lY4 = (lY & 0x40000000);
			lResult = (lX & 0x3FFFFFFF) + (lY & 0x3FFFFFFF);
			if (lX4 & lY4) {
				return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
			}
			if (lX4 | lY4) {
				if (lResult & 0x40000000) {
					return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
				} else {
					return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
				}
			} else {
				return (lResult ^ lX8 ^ lY8);
			}
		};
	
		var _F = function (x, y, z) {
			return (x & y) | ((~x) & z);
		};
		var _G = function (x, y, z) {
			return (x & z) | (y & (~z));
		};
		var _H = function (x, y, z) {
			return (x ^ y ^ z);
		};
		var _I = function (x, y, z) {
			return (y ^ (x | (~z)));
		};
	
		var _FF = function (a, b, c, d, x, s, ac) {
			a = addUnsigned(a, addUnsigned(addUnsigned(_F(b, c, d), x), ac));
			return addUnsigned(rotateLeft(a, s), b);
		};
	
		var _GG = function (a, b, c, d, x, s, ac) {
			a = addUnsigned(a, addUnsigned(addUnsigned(_G(b, c, d), x), ac));
			return addUnsigned(rotateLeft(a, s), b);
		};
	
		var _HH = function (a, b, c, d, x, s, ac) {
			a = addUnsigned(a, addUnsigned(addUnsigned(_H(b, c, d), x), ac));
			return addUnsigned(rotateLeft(a, s), b);
		};
	
		var _II = function (a, b, c, d, x, s, ac) {
			a = addUnsigned(a, addUnsigned(addUnsigned(_I(b, c, d), x), ac));
			return addUnsigned(rotateLeft(a, s), b);
		};
	
		var convertToWordArray = function (str) {
			var lWordCount;
			var lMessageLength = str.length;
			var lNumberOfWords_temp1 = lMessageLength + 8;
			var lNumberOfWords_temp2 = (lNumberOfWords_temp1 - (lNumberOfWords_temp1 % 64)) / 64;
			var lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
			var lWordArray = new Array(lNumberOfWords - 1);
			var lBytePosition = 0;
			var lByteCount = 0;
			while (lByteCount < lMessageLength) {
				lWordCount = (lByteCount - (lByteCount % 4)) / 4;
				lBytePosition = (lByteCount % 4) * 8;
				lWordArray[lWordCount] = (lWordArray[lWordCount] | (str.charCodeAt(lByteCount) << lBytePosition));
				lByteCount++;
			}
			lWordCount = (lByteCount - (lByteCount % 4)) / 4;
			lBytePosition = (lByteCount % 4) * 8;
			lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
			lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
			lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
			return lWordArray;
		};
	
		var wordToHex = function (lValue) {
			var wordToHexValue = "",
				wordToHexValue_temp = "",
				lByte, lCount;
			for (lCount = 0; lCount <= 3; lCount++) {
				lByte = (lValue >>> (lCount * 8)) & 255;
				wordToHexValue_temp = "0" + lByte.toString(16);
				wordToHexValue = wordToHexValue + wordToHexValue_temp.substr(wordToHexValue_temp.length - 2, 2);
			}
			return wordToHexValue;
		};
	
		var x = [],
			k, AA, BB, CC, DD, a, b, c, d, S11 = 7,
	
			S12 = 12,
			S13 = 17,
			S14 = 22,
			S21 = 5,
			S22 = 9,
			S23 = 14,
			S24 = 20,
			S31 = 4,
			S32 = 11,
			S33 = 16,
			S34 = 23,
			S41 = 6,
			S42 = 10,
			S43 = 15,
			S44 = 21;
	
		str = VHC.utils.utf8_encode(str);
		x = convertToWordArray(str);
		a = 0x67452301;
		b = 0xEFCDAB89;
		c = 0x98BADCFE;
		d = 0x10325476;
	
		xl = x.length;
		for (k = 0; k < xl; k += 16) {
			AA = a;
			BB = b;
			CC = c;
			DD = d;
			a = _FF(a, b, c, d, x[k + 0], S11, 0xD76AA478);
			d = _FF(d, a, b, c, x[k + 1], S12, 0xE8C7B756);
			c = _FF(c, d, a, b, x[k + 2], S13, 0x242070DB);
			b = _FF(b, c, d, a, x[k + 3], S14, 0xC1BDCEEE);
			a = _FF(a, b, c, d, x[k + 4], S11, 0xF57C0FAF);
			d = _FF(d, a, b, c, x[k + 5], S12, 0x4787C62A);
			c = _FF(c, d, a, b, x[k + 6], S13, 0xA8304613);
			b = _FF(b, c, d, a, x[k + 7], S14, 0xFD469501);
			a = _FF(a, b, c, d, x[k + 8], S11, 0x698098D8);
			d = _FF(d, a, b, c, x[k + 9], S12, 0x8B44F7AF);
			c = _FF(c, d, a, b, x[k + 10], S13, 0xFFFF5BB1);
			b = _FF(b, c, d, a, x[k + 11], S14, 0x895CD7BE);
			a = _FF(a, b, c, d, x[k + 12], S11, 0x6B901122);
			d = _FF(d, a, b, c, x[k + 13], S12, 0xFD987193);
			c = _FF(c, d, a, b, x[k + 14], S13, 0xA679438E);
			b = _FF(b, c, d, a, x[k + 15], S14, 0x49B40821);
			a = _GG(a, b, c, d, x[k + 1], S21, 0xF61E2562);
			d = _GG(d, a, b, c, x[k + 6], S22, 0xC040B340);
			c = _GG(c, d, a, b, x[k + 11], S23, 0x265E5A51);
			b = _GG(b, c, d, a, x[k + 0], S24, 0xE9B6C7AA);
			a = _GG(a, b, c, d, x[k + 5], S21, 0xD62F105D);
			d = _GG(d, a, b, c, x[k + 10], S22, 0x2441453);
			c = _GG(c, d, a, b, x[k + 15], S23, 0xD8A1E681);
			b = _GG(b, c, d, a, x[k + 4], S24, 0xE7D3FBC8);
			a = _GG(a, b, c, d, x[k + 9], S21, 0x21E1CDE6);
			d = _GG(d, a, b, c, x[k + 14], S22, 0xC33707D6);
			c = _GG(c, d, a, b, x[k + 3], S23, 0xF4D50D87);
			b = _GG(b, c, d, a, x[k + 8], S24, 0x455A14ED);
			a = _GG(a, b, c, d, x[k + 13], S21, 0xA9E3E905);
			d = _GG(d, a, b, c, x[k + 2], S22, 0xFCEFA3F8);
			c = _GG(c, d, a, b, x[k + 7], S23, 0x676F02D9);
			b = _GG(b, c, d, a, x[k + 12], S24, 0x8D2A4C8A);
			a = _HH(a, b, c, d, x[k + 5], S31, 0xFFFA3942);
			d = _HH(d, a, b, c, x[k + 8], S32, 0x8771F681);
			c = _HH(c, d, a, b, x[k + 11], S33, 0x6D9D6122);
			b = _HH(b, c, d, a, x[k + 14], S34, 0xFDE5380C);
			a = _HH(a, b, c, d, x[k + 1], S31, 0xA4BEEA44);
			d = _HH(d, a, b, c, x[k + 4], S32, 0x4BDECFA9);
			c = _HH(c, d, a, b, x[k + 7], S33, 0xF6BB4B60);
			b = _HH(b, c, d, a, x[k + 10], S34, 0xBEBFBC70);
			a = _HH(a, b, c, d, x[k + 13], S31, 0x289B7EC6);
			d = _HH(d, a, b, c, x[k + 0], S32, 0xEAA127FA);
			c = _HH(c, d, a, b, x[k + 3], S33, 0xD4EF3085);
			b = _HH(b, c, d, a, x[k + 6], S34, 0x4881D05);
			a = _HH(a, b, c, d, x[k + 9], S31, 0xD9D4D039);
			d = _HH(d, a, b, c, x[k + 12], S32, 0xE6DB99E5);
			c = _HH(c, d, a, b, x[k + 15], S33, 0x1FA27CF8);
			b = _HH(b, c, d, a, x[k + 2], S34, 0xC4AC5665);
			a = _II(a, b, c, d, x[k + 0], S41, 0xF4292244);
			d = _II(d, a, b, c, x[k + 7], S42, 0x432AFF97);
			c = _II(c, d, a, b, x[k + 14], S43, 0xAB9423A7);
			b = _II(b, c, d, a, x[k + 5], S44, 0xFC93A039);
			a = _II(a, b, c, d, x[k + 12], S41, 0x655B59C3);
			d = _II(d, a, b, c, x[k + 3], S42, 0x8F0CCC92);
			c = _II(c, d, a, b, x[k + 10], S43, 0xFFEFF47D);
			b = _II(b, c, d, a, x[k + 1], S44, 0x85845DD1);
			a = _II(a, b, c, d, x[k + 8], S41, 0x6FA87E4F);
			d = _II(d, a, b, c, x[k + 15], S42, 0xFE2CE6E0);
			c = _II(c, d, a, b, x[k + 6], S43, 0xA3014314);
			b = _II(b, c, d, a, x[k + 13], S44, 0x4E0811A1);
			a = _II(a, b, c, d, x[k + 4], S41, 0xF7537E82);
			d = _II(d, a, b, c, x[k + 11], S42, 0xBD3AF235);
			c = _II(c, d, a, b, x[k + 2], S43, 0x2AD7D2BB);
			b = _II(b, c, d, a, x[k + 9], S44, 0xEB86D391);
			a = addUnsigned(a, AA);
			b = addUnsigned(b, BB);
			c = addUnsigned(c, CC);
			d = addUnsigned(d, DD);
		}
	
		var temp = wordToHex(a) + wordToHex(b) + wordToHex(c) + wordToHex(d);	
		return temp.toLowerCase();	
	},
	
	utf8Encode: function(argString)
	{
		//seee http://phpjs.org/functions/utf8_encode:577
		
		if (argString === null || typeof argString === "undefined") {
			return "";
		}
		var string = (argString + ''); // .replace(/\r\n/g, "\n").replace(/\r/g, "\n");
		var utftext = "",
		start, end, stringl = 0;
		
		start = end = 0;    stringl = string.length;
		for (var n = 0; n < stringl; n++)
		{
			var c1 = string.charCodeAt(n);
			var enc = null;
			if (c1 < 128){
				end++;
			} else if (c1 > 127 && c1 < 2048) {
				enc = String.fromCharCode((c1 >> 6) | 192) + String.fromCharCode((c1 & 63) | 128);
			} else {
				enc = String.fromCharCode((c1 >> 12) | 224) + String.fromCharCode(((c1 >> 6) & 63) | 128) + String.fromCharCode((c1 & 63) | 128);
			}
			if (enc !== null)
			{
				if (end > start) {
					utftext += string.slice(start, end);
				}
				utftext += enc;
				start = end = n + 1;
			}
		} 
		if (end > start){
			utftext += string.slice(start, stringl);
		}
		return utftext;
	},
	
	utf8Decode: function(str_data)
	{
		var tmp_arr = [],
		i = 0,
		ac = 0,
		c1 = 0,
		c2 = 0,
		c3 = 0;		
		str_data += '';		
		while (i < str_data.length)
		{
			c1 = str_data.charCodeAt(i);
			if (c1 < 128) {
				tmp_arr[ac++] = String.fromCharCode(c1);
				i++;
			} else if (c1 > 191 && c1 < 224){
				c2 = str_data.charCodeAt(i + 1);
				tmp_arr[ac++] = String.fromCharCode(((c1 & 31) << 6) | (c2 & 63));
				i += 2;
			} else {
				c2 = str_data.charCodeAt(i + 1);
				c3 = str_data.charCodeAt(i + 2);
				tmp_arr[ac++] = String.fromCharCode(((c1 & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
		} 
		return tmp_arr.join('');
	},
	
	inArray: function(needle, haystack, argStrict)
	{
		//in_array('van', ['Kevin', 'van', 'Zonneveld']);
		
		var key = '', strict = !! argStrict;		
		if (strict){
			for (key in haystack)
			{
				if (haystack[key] === needle)
				{
					return true;
				}
			}
		} else {
			for (key in haystack)
			{
				if (haystack[key] == needle)
				{
					return true;
				}
			}
		} 
		return false;
	},
	
	extract: function(arr, type, prefix)
	{
		//see http://phpjs.org/functions/extract:397
		/*
			size = 'large';
			var var_array = {'color' : 'blue', 'size' : 'medium', 'shape' : 'sphere'};
			extract(var_array, 'EXTR_PREFIX_SAME', 'wddx');
			color+'-'+size+'-'+shape+'-'+wddx_size;
			=> blue-large-sphere-medium
		*/

		if (Object.prototype.toString.call(arr) === '[object Array]' && (type !== 'EXTR_PREFIX_ALL' && type !== 'EXTR_PREFIX_INVALID'))
		{
			return 0;
		}
		var targetObj = window;
		if (this.php_js && this.php_js.ini && this.php_js.ini['phpjs.extractTargetObj'] && this.php_js.ini['phpjs.extractTargetObj'].local_value)
		{
			targetObj = this.php_js.ini['phpjs.extractTargetObj'].local_value;
		}
		var chng = 0;		
		for (var i in arr)
		{
			var validIdent = /^[_a-zA-Z$][\w|$]*$/;
			var prefixed = prefix + '_' + i;
			try {
				switch (type)
				{
					case 'EXTR_PREFIX_SAME' || 2:
						if (targetObj[i] !== undefined)
						{
							if (prefixed.match(validIdent) !== null) {
								targetObj[prefixed] = arr[i];
								++chng;
							}
						} else {
							targetObj[i] = arr[i];
							++chng;
						}
					break;
					
					case 'EXTR_SKIP' || 1:
						if (targetObj[i] === undefined)
						{
							targetObj[i] = arr[i];
							++chng;
						}
					break;
					
					case 'EXTR_PREFIX_ALL' || 3:
						if (prefixed.match(validIdent) !== null)
						{
							targetObj[prefixed] = arr[i];
							++chng;
						}
					break;
					
					case 'EXTR_PREFIX_INVALID' || 4:
						if (i.match(validIdent) !== null)
						{
							if (prefixed.match(validIdent) !== null) {
								targetObj[prefixed] = arr[i];
								++chng;
							}
						} else {
							targetObj[i] = arr[i];
							++chng;
						}
					break;
					
					case 'EXTR_IF_EXISTS' || 6:
						if (targetObj[i] !== undefined) {
							targetObj[i] = arr[i];
							++chng;
						}
					break;
					
					case 'EXTR_PREFIX_IF_EXISTS' || 5:
						if (targetObj[i] !== undefined && prefixed.match(validIdent) !== null)
						{
							targetObj[prefixed] = arr[i];
							++chng;
						}
					break;
					
					case 'EXTR_REFS' || 256:
						throw 'The EXTR_REFS type will not work in JavaScript';
						
					case 'EXTR_OVERWRITE' || 0:								
					default:
						targetObj[i] = arr[i];
						++chng;
					break;
				}
			} catch (e) {
			}
		}
		return chng;
	},
	
	log: function(msg)
	{
		if( $.browser.msie )
			return '';
		console.log(msg);
		return '';
	},
	
	warn: function(msg)
	{
		if( $.browser.msie )
			return '';
		console.warn(msg);
		return '';
	}
};
//========================================= core


VHC.core = 
{
	pageHeight: function(){
		var doc_height = $('body').height();
		var win_height = $(window).height();
		var mc_height = $('.mc').height();
		//console.log(doc_height+'__'+win_height+'__'+mc_height);
		if(doc_height < win_height){
			$('.mc').css('height',mc_height+(win_height-doc_height));
		}
		
	},
	
	mainMiddHeight: function()
	{
		VHC.utils.log('Call VHC.mainMiddHeight()');
		
		var mct_cl = $('.mainMidd .cl');
		var mct_cr = $('.mainMidd .cr');
		if(mct_cl.height() > mct_cr.height()){
			mct_cr.css('height',mct_cl.height());
		}else if(mct_cl.height() < mct_cr.height()){
			$('.bct',mct_cl).css('height',mct_cr.height());
		}
	},
	
	navbar: function()
	{
		VHC.utils.log('Call VHC.navbar()');
		$('.navbar li ul').each(function(){
			$('li:first', this).addClass('f');
			$('li:last', this).addClass('l');
		});
		
		$('.navbar li').live('mouseover mouseleave',function(e)
		{
			if( e.type == 'mouseover'){
				$(this).addClass('hover');
				$('ul:first',this).show();
			}else{
				$(this).removeClass('hover');
				$('ul:first',this).hide();
			}
		});
	}
};

/*VHC.extend = function (childClass, parentClass) {
	var F = function(){};
	F.prototype = childClass.prototype;
	childClass.prototype = new F();
	childClass.prototype.constructor = childClass;
	childClass.superclass = parentClass.prototype;
}*/