$(function(){	
	VHC.core.navbar();
	VHC.core.mainMiddHeight();
	VHC.utils.tborder();
	
	$('.security_code').bind('click',function(){
		$(this).attr('src','class/captcha.jpg?characters='+$(this).attr('characters')+'&width='+$(this).attr('width')+'&height='+$(this).attr('height')+'&t='+Math.random());
	});
	
	$('input, textarea').live('focusin focusout',function(e){
		if(e.type == 'focusin'){
			$(this).addClass('focus');
		}else{
			$(this).removeClass('focus');
		}
	});
	
	$('a').live('click', function(){
		var trigger = $.trim($(this).attr('trigger'));
		if(trigger != '')
		{
			try{
				var trigger = eval(trigger);
				$(trigger[0]).trigger(trigger[1]);
			}catch(err){
				VHC.utils.notice(err);
			}
			return false;
		}
	});
	
	$('.anwBox .listview .cm .p_rs').bind('mouseover mouseleave',function(e){
		if(e.type == 'mouseover'){
			$(this).addClass('hover');
		}else{
			$(this).removeClass('hover');
		}
	});
	
	/*$('a[confirm=1]').bind('click',function(){
		var _this = this;
		var options = {
			confirm: true,
			buttons:{
				'confirm': {
					html: 'Xác nhận',
					class: 'confirm',
					click: function(){
						window.location.href = $(_this).attr('href')
					}
				},
				'cancel': {
					html: 'Hủy',
					click: function(){
						$().colorbox.close();
					}
				}
			}
		};
		VHC.utils.notice('Ban có chắc chắn muốn đi đến trang này?', options);
		return false;
	});*/
	
});

$(window).bind('load',function(){
	VHC.core.pageHeight();
	/*$.post('md5.php',function(data){
		var options = {
			title: 'Form',
			buttons:{
				'save': {
					html: 'Lưu lại',
					class: 'confirm',
					click: function(){
						$().colorbox.submit();
					}
				},
				'cancel': {
					html: 'Hủy',
					click: function(){
						$().colorbox.close();
					}
				}
			}
		};
		
		VHC.utils.notice(data, options);	
	});*/
	
}).bind('resize',function(){
	VHC.core.pageHeight();
});