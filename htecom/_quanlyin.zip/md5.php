<form action="" onsubmit="VHC.utils.notice('fdfdfd fdfd'); return false;">
<?
	echo md5('quanghoa');
?>
</form>