<?php

class Admin extends VanillaModel {
		var $abstract = true;
}