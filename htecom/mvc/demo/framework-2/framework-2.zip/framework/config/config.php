<?php

/** Configuration Variables **/

define ('DEVELOPMENT_ENVIRONMENT',true);


define('DB_NAME', 'framework');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
define('DB_HOST', 'localhost');

define('BASE_PATH','http://localhost/framework');


define('PAGINATE_LIMIT', '5');