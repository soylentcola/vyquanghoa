<?php

require_once ('public' . DIRECTORY_SEPARATOR . 'index.php');

?>