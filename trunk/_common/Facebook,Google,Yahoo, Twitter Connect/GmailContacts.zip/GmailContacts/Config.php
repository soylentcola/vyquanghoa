<?php
$consumer_key='Your website domain';
$consumer_secret='Secret Key';
$callback='http://website.com/Contacts.php';
$emails_count='500';
?>