<?php
 header("Location: fblogin.php");
?>